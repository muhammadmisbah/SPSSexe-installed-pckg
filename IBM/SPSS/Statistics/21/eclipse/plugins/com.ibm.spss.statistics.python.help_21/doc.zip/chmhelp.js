/************************************************************************
** Licensed Materials - Property of IBM
**
** IBM SPSS Products: Documentation Tools
**
** (C) Copyright IBM Corp. 2000, 2011
**
** US Government Users Restricted Rights - Use, duplication or disclosure
** restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************************/

<!-- hide scripts from silly old browsers

//////////////////////////////////////////////////////////
//             Localizable strings                      //
//////////////////////////////////////////////////////////

var stb_topics_found = "Topics Found";
var stb_select_a_topic = "Select a topic:";
var stb_close_popup = "Close popup window";

//////////////////////////////////////////////////////////
//             End Localizable strings                  //
//////////////////////////////////////////////////////////


function smartLink(targetList) {
//handle links with multiple targets.
//targets are passed as items in a targetList array
//with the URL for each target followed by its title
//thus a single target the value of targetList would be "['myURL.htm', 'My Title']"
//
//CH: updated 2/2002 to handle modules; each entry now has 3 items: URL, title, and module name
	
  //In the case of a single target, just go there
  if (targetList.length <= 4) { //4 'cuz the array may end with an extra comma if written by a stylesheet
    // don't need to check for module because the entire link should be
    // hidden if the link is in a missing module
    location.href=targetList[0];

  //If multiple targets are specified, list the topics so the user can choose
  } else {
  

    var newContent = "<HTML><HEAD>\n";
    newContent += "<SCRIPT type=\"text/javascript\" src=\"../helploc.js\"></SCRIPT>\n";
    // in following line, we have to break up the HEAD closing tag, because
    // eclipse 3.3 uses it as a marker to inject its own bit of JS code; but when
    // it tries stick it in here it just bolloxes up the works
    newContent += "<TITLE>" + stb_topics_found + "</TITLE>\n</HE" + "AD>\n";
    newContent += '<BODY><H1 style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:x-small; font-weight:bold;">' + stb_select_a_topic + '</H1>\n';

      for(var i = 0; i < targetList.length; i+=3) {
        if (targetList[i] != null) {
          if (!modules_defined || targetList[i+2]=="" || eval(targetList[i+2])) {
            newContent += '<div style="display:block; font-family:Verdana; font-size:x-small; margin-top:4px">'
            newContent += '<A href="' + targetList[i] + '">' + targetList[i+1] + "</A><BR>"
            newContent += '</div>\n'
          }
        }
      }

    newContent += "</BODY>\n</HTML>";
    document.write(newContent);
    document.close(); //close layout stream
  }
}

// This function pops up a little browser window containing the passed text--very
// useful for glossary and bibliography xrefs

var popupwin = null;

function popup(title,text,event) {
  //pops up a mini window to display the text string passed
    if (event == null) event = window.event;
    // remove existing popup if any
    p = document.getElementById("defwindow");
    if (p != null) p.parentNode.removeChild(p);

    // create new popup
    b = document.getElementsByTagName("body").item(0);
    if (location.protocol=="ms-help:") b = document.getElementById("nstext");
    t = event.target?event.target:event.srcElement;
    p = document.createElement("div");
    newx = parseInt((event.clientX>0?event.clientX:0) + b.scrollLeft) + 10 + "px";
    newy = parseInt((event.clientY>0?event.clientY:0) + b.scrollTop) + 10 + "px";

    // set popup div attributes
    p.style.position = "absolute";
    p.style.top = newy;
    p.style.left = newx;
    p.style.width = "200px";
    p.style.height = "auto";
    p.style.zIndex = 100;
    p.style.padding = "3px";
    p.style.backgroundColor = "white";
    p.style.border = "1px solid black";
    p.style.textIndent = "0px";
    p.id = "defwindow";
    p.className = "popup";

    // add closer control
    closer = document.createElement("div");
    closerbutton = document.createElement("a");
    closerbutton.setAttribute("href","javascript:document.getElementById('defwindow').parentNode.removeChild(document.getElementById('defwindow'));void(0);");
    closerbutton.setAttribute("title",stb_close_popup);
    closerimage = document.createElement("img");
    closerimage.setAttribute("src","images/popup_closer.gif");
    closerimage.setAttribute("alt",stb_close_popup);
    closerimage.setAttribute("border","0");
    closerbutton.appendChild(closerimage);
    closerbutton.style.fontSize = "14px";
    closerbutton.style.lineHeight = "11px";
    closerbutton.style.textDecoration = "none";
    closerbutton.style.color = "black";
    closer.appendChild(closerbutton);

    // set title
    titlediv = document.createElement("div");
    titlediv.setAttribute("class","glossary-term");
    titlediv.style.fontWeight = "bold";
    titlediv.style.marginRight = "10px";
    titlediv.appendChild(document.createTextNode(title));
    titlediv.style.cursor = "move";
    titlediv.onmousedown = popup_drag;
    p.appendChild(titlediv);
    p.appendChild(document.createElement("hr"));

    // set text
    textdiv = document.createElement("div");
    textdiv.setAttribute("class","glossary-definition");
//    textdiv.appendChild(document.createTextNode(text));
    textdiv.innerHTML = text;
    p.appendChild(textdiv);
    p.appendChild(closer);
    closer.style.position = "absolute";
    closer.style.right = "2px";
    closer.style.top = "2px";
//    closer.style.styleFloat = "right"; //IE
//    closer.style.cssFloat = "right";   //Mozilla
    closer.style.border = "1px solid black";

    // add it to document
    if (t.nextSibling) t.parentNode.insertBefore(p,t);
    else (t.parentNode.appendChild(p));
    //b.appendChild(p);
    setTimeout('closerimage.setAttribute("src","images/popup_closer.gif");',100);
   
    // set window focus to closer
    p.focus();
}

function popup_drag(event) {
  // adapted from code in Flanagan, Javascript:The Definitive Guide, 4e
  // pp 372-373
  if (event == null) event = window.event;
  var popup = document.getElementById("defwindow");
  var x = parseInt(popup.style.left);
  var y = parseInt(popup.style.top);
  var mouseX = event.clientX;
  var mouseY = event.clientY;
  document.onmousemove = popup_move;
  document.onmouseup = popup_drop;
  event.stopPropagation?event.stopPropagation():event.cancelBubble=true;
  event.preventDefault?event.preventDefault():event.returnValue=false;
  
  function popup_move(event) {
    if (event == null) event = window.event;
    popup.style.left = parseInt(popup.style.left) + (event.clientX - mouseX) + "px";
    popup.style.top = parseInt(popup.style.top) + (event.clientY - mouseY) + "px";
    mouseX = event.clientX;
    mouseY = event.clientY;
    event.stopPropagation?event.stopPropagation():event.cancelBubble=true;
  }
  
  function popup_drop(event) {
    if (event == null) event = window.event;
    document.onmousemove = null;
    document.onmouseup = null;
    event.stopPropagation?event.stopPropagation():event.cancelBubble=true;
  }
    
}

// This function pops up a browser window containing showing the linked graphic
function graphicpopup(title,src) {
/*  if (typeof popupwin != "undefined") {
    popupwin.close();
  } */
  popupwin = null;
  popupwin = window.open("","popup","resizable");
  html = "<HTML>\n<HEAD>\n<TITLE>" + title + "</TITLE>\n" + 
   "<BODY>\n" +
   "<img src=" + "'" + "images/" + src + "'" + ">" + "\n" +
   "</BODY>\n</HTML>\n";
  popupwin.document.write(html);
  popupwin.document.close();
}

function filter_modules_topic() {
  if ((typeof modules_defined != "undefined") && modules_defined) {
    spans = document.getElementsByTagName("SPAN");
    for (i=0;i<spans.length;i++) {
      if (spans[i].className.substring(0,7)=="module_") {
        if (!eval(spans[i].className)) {
	  // module is missing, so hide the span
	  spans[i].style.display="none";
        }
      }
    }
    divs = document.getElementsByTagName("DIV");
    for (i=0;i<divs.length;i++) {
      if (divs[i].className.substring(0,7)=="module_") {
        if (!eval(divs[i].className)) {
	  // module is missing, so hide the span
	  divs[i].style.display="none";
        }
      }
    }
  }	
}

function get_absolute_path() {
  // returns the directory of the current page as an absolute
  // directory. Primarily used to allow CHM files to access
  // external HTML files (e.g. tutorials and script files)
  var X, Y, sl, a, ra, re, link, hr;
  ra = /:/;
  re = /::/;
  // for merged files, sometimes the file refs are daisy-chained
  // in a funny way, e.g. d:/files/foo.chm::d:/files/bar.chm::baz.htm.
  // so first we have to get rid of anything after the first file
  // reference
  end = location.href.search(re);
  link = (end>0)?location.href.substring(0,end):location.href;
  link = unescape(link); //convert %20's back into spaces
  a = link.search(ra);
  if (a == 2)
    X = 14;
  else
    X = 7;
  sl = /[\\\/][^\\\/]*$/;
  Y = link.search(sl) + 1;
  link = link.substring(X, Y);
  //  alert('get_absolute_path():\n' +
  //	'end(position of /::/) = ' + end + '\n' +
  //	'link = ' + ((end>0)?location.href.substring(0,end):location.href) + '\n' +
  //	'a (position of /:/) = ' + a + '\n' +
  //	'X (start of substring) = ' + X + '\n' +
  //	'Y (end of substring) = ' + Y + '\n' +
  //	'final link = ' + link);
  return link;
}


function open_external_file(fn) {
  //opens a file outside the CHM file with correct handling for relative paths
  link = fn.replace("\\","/");
  if (link.substring(0,2) == "//") {
    // UNC filename
    link = "file:///" + link;
  }
  else if (link.substring(0,1) == "/") {
    // absolute windows path, have to extract the drive letter from the absolute path
    drive = get_absolute_path().substring(0,2);
    link = "file:///" + drive + link;
  }
  else if (relative_path(fn)) {
    // relative path, convert to absolute based on location of CHM
    link = 'file:///' + get_absolute_path() + link;
  }
  //location.href = link;
  window.open(link,"tutorial_window");
}

function relative_path(path) {
  // checks whether the given path is relative or not
  result = true;
  if ((path.indexOf(":") != -1)) {
    result = false;
  }
  return result;
}

function loadChm(filespec) {
  // Loads an external CHM file from a topic in another CHM file
  var target = "MS-ITS:" + get_absolute_path() + filespec;
  window.open(target,"tutorial_window","resizable=yes");
}


// This function controls the displaying/hiding of collapsible elements
function expando(context) {
  children = document.getElementById(context).childNodes;
  for (i=0;i<children.length;i++) {
    if (children.item(i).tagName == "DIV") {
      if (children.item(i).style.display == "block") {
	// it's currently open, so close it
        children.item(i).style.display = "none";
        document.getElementById(context+'_opener').style.display = "inline";
        document.getElementById(context+'_opener').focus();
        document.getElementById(context+'_closer').style.display = "none";
      }
      else {
	// it's closed, so open it
        children.item(i).style.display = "block";
        document.getElementById(context+'_opener').style.display = "none";
        document.getElementById(context+'_closer').style.display = "inline";
        document.getElementById(context+'_closer').focus();
      }
    }
  }
}

//
//
//      MathML rendering support functions
//
//      Adapted from David Carlisle's pmathmlcss.xsl stylesheet
//      see http://www.w3.org/Math/XSL/

function malign (l)
{
var m = 0;
for ( i = 0; i < l.length ; i++)
{
 m = Math.max(m,l[i].offsetLeft);
}
for ( i = 0; i < l.length ; i++)
{
 l[i].style.marginLeft=m - l[i].offsetLeft;
}
}

function mrowStretch (opid,opt,ope,opm,opb){
opH = document.getElementById(opid).offsetHeight;
var opH;
var i;
var es;
lh = "100%";
if (mrowH > opH * 2) {
m= "<font size='+1' face='symbol' style='line-height:" + lh + "'>" + opm + "</font><br/>" ;
if ((mrowH < opH * 3) && (opm == ope) ) m="";
es="";
for ( i = 3; i <= mrowH / (2*opH) ; i += 1) es += "<font size='+1' face='symbol' style='line-height:" + lh + "'>" + ope + "</font><br/>" ;
document.getElementById(opid).innerHTML="<table class='lr'><tr><td><font size='+1' face='symbol' style='line-height:" + lh + "'>" +
          opt + "</font><br/>" +
       es +
       m +
       es +
 "<font size='+1' face='symbol' style='line-height:" + lh + "'>" + opb + "</font></td></tr></table>";
}
}

function msubsup (bs,bbs,x,b,p){
p.style.setExpression("top",bs +" .offsetTop -"  + (p.offsetHeight/2));
b.style.setExpression("top",bs + ".offsetTop + " + (bbs.offsetHeight - b.offsetHeight*.5));
x.style.setExpression("marginLeft",Math.max(p.offsetWidth,b.offsetWidth));
	document.recalc(true);
}

function msup (bs,x,p){
p.style.setExpression("top",bs +" .offsetTop -"  + (p.offsetHeight/2));
x.style.setExpression("marginLeft", bs +"p.offsetWidth");
x.style.setExpression("height", bs + ".offsetHeight + " + p.offsetHeight);
document.recalc(true);
}

function msub (bs,x,p){
p.style.setExpression("top",bs +" .offsetTop +"  + (p.offsetHeight/2));
x.style.setExpression("marginLeft", bs +"p.offsetWidth");
x.style.setExpression("height", bs + ".offsetHeight + " + p.offsetHeight);
document.recalc(true);
}

function munderover(id) {
  // rearranges elements of an munderover group
  group = document.getElementById(id);
  // find width = max child width
  w = 0;
  kids = new Array();
  for (var i=0; i < group.childNodes.length; i++) {
    kid = group.childNodes.item(i);
    if (kid.offsetWidth) {
      w = Math.max(w,kid.offsetWidth);
      kids.push(kid);
    }
  }
  // center top element and move it up
  t = kids[0];
  mid = kids[1];
  b = kids[2];
  strut = kids[3];
  ieadjust = document.all?6:0;
  tleft = (0.5 * w - 0.5 * t.offsetWidth + ieadjust);
  t.style.left = tleft + "px";
  t.style.top = (-mid.offsetHeight) + "px";
  // center middle element
  mleft = (0.5*w - 0.5*mid.offsetWidth - t.offsetWidth)
  mid.style.left = mleft + "px";
  // center bottom element and move it down
  bleft = (0.5 * w - 0.5 * b.offsetWidth  - mid.offsetWidth - t.offsetWidth - ieadjust);
  b.style.left = bleft + "px";
  b.style.top = (b.offsetHeight + 3) + "px";
  // make sure the equation is tall enough to contain the thing
  strut.style.top = -mid.offsetHeight + "px";
  strut.style.width = "30px";
  strut.style.lineHeight = t.offsetHeight + mid.offsetHeight + b.offsetHeight + "px";
  // add negative space after to account for all the shifting around
  group.style.marginRight = (bleft - 30 + w) + "px";
}

function toggle (x) {
for ( i = 0 ; i < x.childNodes.length ; i++) {
if (x.childNodes.item(i).style.display=='inline') {
 x.childNodes.item(i).style.display='none';
if ( i+1 == x.childNodes.length) {
x.childNodes.item(0).style.display='inline';
} else {
x.childNodes.item(i+1).style.display='inline';
};
break;
}
}
}


// end hiding scripts from silly old browswers -->



